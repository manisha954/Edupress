/** @format */

import React from "react";

const LoadingSpinner: React.FC = () => {
  return <div className="spinner"></div>;
};

export default LoadingSpinner;
