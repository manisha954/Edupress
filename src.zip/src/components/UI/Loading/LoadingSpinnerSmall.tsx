/** @format */

import React from "react";

const LoadingSpinnerSmall: React.FC = () => {
  return <div className="spinner-small"></div>;
};

export default LoadingSpinnerSmall;
