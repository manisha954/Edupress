import AllCourses from "@/components/LandingPage.tsx/AllCourses";
import Footer from "@/components/LandingPage.tsx/Footer";
import Navbar from "@/components/LandingPage.tsx/Navbar";
import React from "react";

export default function page() {
  return (
    <div>
      <Navbar />
      <AllCourses />
      <Footer />
    </div>
  );
}
