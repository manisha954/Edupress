import AllArticle from "@/components/Blog/AllArticle";
import React from "react";

export default function page() {
  return (
    <div>
      <AllArticle />
    </div>
  );
}
