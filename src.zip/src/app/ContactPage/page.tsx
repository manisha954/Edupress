import Contact from "@/components/Pages/Contact";
import React from "react";

export default function page() {
  return (
    <div>
      <Contact />
    </div>
  );
}
