import CoursePage from "@/components/CorsesExpand";
import FAQSection from "@/components/Pages/Faq";
import HeroSection from "@/components/LandingPage.tsx/HeroSection";
import Navbar from "@/components/LandingPage.tsx/Navbar";
import LoginPage from "@/components/LoginPage/LoginPage";
import Error from "@/components/Pages/Error";
import React from "react";
import Contact from "@/components/Pages/Contact";
import AllArticle from "@/components/Blog/AllArticle";
import BlogPost from "@/components/Blog/BlogPost";

export default function page() {
  return (
    <div>
      {/* <Navbar />
      <HeroSection /> */}
      {/* <LoginPage /> */}
      {/* <BlogPost /> */}
      {/* <CoursePage /> */}
      {/* <FAQSection /> */}
      {/* <Error />  */}
      {/* <Contact /> */}
      {/* <AllArticle /> */}
    </div>
  );
}
