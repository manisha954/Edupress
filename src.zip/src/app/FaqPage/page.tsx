import FAQSection from "@/components/Pages/Faq";
import React from "react";

export default function page() {
  return (
    <div>
      <FAQSection />
    </div>
  );
}
