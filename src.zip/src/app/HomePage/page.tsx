import HeroSection from "@/components/LandingPage.tsx/HeroSection";
import React from "react";

export default function page() {
  return (
    <div>
      <HeroSection />
    </div>
  );
}
